const Arr = ["HTML", "CSS", "Javascript", "PHP", "Less", "Angular", "React"];

var onChange = function(evt){
    const value = this.value;
    const result = document.querySelector(".result");
    if(!value){
        result.innerHTML = "";
        return
    }
    const data = Arr.filter(e => e.toLowerCase().includes(value.toLowerCase()));
    var res = '<ul class="list-group">';
    data.forEach(e =>{
            res += '<li class="list-group-item d-flex justify-content-between align-items-center">'+e+'</li>';
    })
    res +='</ul>';
    result.innerHTML = res;
}

const input = document.querySelector("#form8");
input.addEventListener("input", onChange, false);